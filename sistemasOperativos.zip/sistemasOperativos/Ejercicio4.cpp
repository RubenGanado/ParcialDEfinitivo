#include <iostream>
#include <sys/wait.h>
#include <unistd.h>

using namespace std;

// -------------------- FUNCIONES AUXILIARES --------------------

void CrearHijoSimple(const string &nombre) {
    pid_t pid = fork();
    if (pid == -1) {
        cerr << "Error al crear proceso " << nombre << endl;
        return;
    }

    if (pid == 0) {
        cout << nombre << " -> PID: " << getpid()
             << " | PPID: " << getppid() << endl;
        _exit(0);
    }
    wait(nullptr);
}

void CrearHijoConHijo(const string &nombre, const string &subnombre) {
    pid_t pid = fork();
    if (pid == -1) {
        cerr << "Error al crear proceso " << nombre << endl;
        return;
    }

    if (pid == 0) {
        cout << nombre << " -> PID: " << getpid()
             << " | PPID: " << getppid() << endl;

        CrearHijoSimple(subnombre);
        _exit(0);
    }
    wait(nullptr);
}

// -------------------- HIJOS DEL PADRE --------------------

void Hijo0() {
    cout << "[Hijo 0] -> PID: " << getpid()
         << " | PPID: " << getppid() << " (sin hijos)" << endl;
}

void Hijo1() {
    cout << "[Hijo 1] -> PID: " << getpid()
         << " | PPID: " << getppid() << endl;

    CrearHijoSimple("   [Hijo 1.0]");
}

void Hijo2() {
    cout << "[Hijo 2] -> PID: " << getpid()
         << " | PPID: " << getppid() << endl;

    // Hijo 2.0 con un hijo (2.0.0)
    CrearHijoConHijo("   [Hijo 2.0]", "      [Hijo 2.0.0]");

    // Hijo 2.1 sin hijos
    CrearHijoSimple("   [Hijo 2.1]");
}

void Hijo3() {
    cout << "[Hijo 3] -> PID: " << getpid()
         << " | PPID: " << getppid() << endl;

    // Hijo 3.0 sin hijos
    CrearHijoSimple("   [Hijo 3.0]");

    // Hijo 3.1 con un hijo (3.1.0)
    CrearHijoConHijo("   [Hijo 3.1]", "      [Hijo 3.1.0]");

    // Hijo 3.2 con dos hijos (3.2.0 y 3.2.1)
    pid_t pid = fork();
    if (pid == 0) {
        cout << "   [Hijo 3.2] -> PID: " << getpid()
             << " | PPID: " << getppid() << endl;

        // Hijo 3.2.0 con un hijo (3.2.0.0)
        CrearHijoConHijo("      [Hijo 3.2.0]", "         [Hijo 3.2.0.0]");

        // Hijo 3.2.1 sin hijos
        CrearHijoSimple("      [Hijo 3.2.1]");

        _exit(0);
    }
    wait(nullptr);
}

// -------------------- FUNCIÓN PRINCIPAL --------------------

int main() {
    cout << "[PADRE] -> PID: " << getpid()
         << " | PPID: " << getppid() << endl;

    for (int i = 0; i < 4; i++) {
        pid_t pid = fork();

        if (pid == -1) {
            cerr << "Error al crear hijo " << i << endl;
            return 1;
        }

        if (pid == 0) {
            switch (i) {
                case 0: Hijo0(); break;
                case 1: Hijo1(); break;
                case 2: Hijo2(); break;
                case 3: Hijo3(); break;
            }
            _exit(0);
        }
    }

    // Esperar a los 4 hijos del padre
    for (int i = 0; i < 4; i++) {
        wait(nullptr);
    }

    cout << "[PADRE] Todos los hijos han terminado." << endl;
    return 0;
}
