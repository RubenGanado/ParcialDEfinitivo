// ejercicio2.cpp
#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int arr[12] = {1,2,3,4,5,6,7,8,9,10,11,12}; // ejemplo
    pid_t pid1, pid2;

    // Crear primer hijo (hijo1)
    pid1 = fork();
    if (pid1 == -1) {
        std::cerr << "fork() falló\n";
        return 1;
    }
    if (pid1 == 0) {
        // Hijo1 suma arr[4..7]
        int s = 0;
        for (int i = 4; i <= 7; ++i) s += arr[i];
        std::cout << "Hijo1 (PID=" << getpid() << ") suma parcial = " << s << std::endl;
        return 0;
    }

    // En padre: crear segundo hijo (hijo2)
    pid2 = fork();
    if (pid2 == -1) {
        std::cerr << "fork() falló\n";
        return 1;
    }
    if (pid2 == 0) {
        // Hijo2 suma arr[8..11]
        int s = 0;
        for (int i = 8; i <= 11; ++i) s += arr[i];
        std::cout << "Hijo2 (PID=" << getpid() << ") suma parcial = " << s << std::endl;
        return 0;
    }

    // Padre suma arr[0..3]
    int s_parent = 0;
    for (int i = 0; i <= 3; ++i) s_parent += arr[i];
    std::cout << "Padre (PID=" << getpid() << ") suma parcial = " << s_parent << std::endl;

    // Esperar a ambos hijos
    int status;
    pid_t ended;
    int waited = 0;
    while ((ended = wait(&status)) > 0) {
        ++waited;
        // opcional: mostrar qué hijo terminó
        std::cout << "Proceso hijo terminado con PID = " << ended << std::endl;
        if (waited == 2) break;
    }

    std::cout << "Han terminado mis hijos" << std::endl;
    return 0;
}
