// ejercicio3.cpp
#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <cstdlib>
#include <ctime>

int main() {
    const int N = 3;
    pid_t pids[N];
    std::srand(time(nullptr) ^ getpid());

    for (int i = 0; i < N; ++i) {
        pid_t pid = fork();
        if (pid == -1) {
            std::cerr << "fork() falló\n";
            return 1;
        } else if (pid == 0) {
            // Hijo corredor
            std::cout << "Corredor " << (i+1) << " (PID=" << getpid() << ") listo\n";
            int sleep_time = (std::rand() % 5) + 1; // 1..5 segundos
            sleep(sleep_time);
            std::cout << "Hijo (PID=" << getpid() << ") ha llegado a la meta tras "
                      << sleep_time << "s\n";
            return 0;
        } else {
            // Padre guarda PID
            pids[i] = pid;
        }
    }

    // Padre espera e imprime orden de llegada
    int rank = 1;
    int status;
    pid_t finished_pid;
    while ((finished_pid = wait(&status)) > 0) {
        std::cout << rank << "º en llegar: Hijo con PID = " << finished_pid << std::endl;
        ++rank;
        if (rank > N) break;
    }

    std::cout << "Carrera finalizada" << std::endl;
    return 0;
}
