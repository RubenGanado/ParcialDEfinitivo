#include <unistd.h>
#include <iostream>

int main() {
    pid_t pid;
    pid = fork(); // crea un proceso

    switch(pid) {
        case -1:
            std::cerr << "No se ha podido crear el hijo" << std::endl;
            return 1;

        case 0: // Proceso hijo
            std::cout << "Soy el HIJO, mi PID es " << getpid()
                      << " y mi PPID es " << getppid() << std::endl;
            break;

        default: // Proceso padre
            std::cout << "Soy el PADRE, mi PID es " << getpid()
                      << " y mi PPID es " << getppid() << std::endl;
            // No se espera al hijo (según el enunciado)
    }

    return 0;
}
